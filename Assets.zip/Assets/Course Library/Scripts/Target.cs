using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Target : MonoBehaviour
{
    // Start is called before the first frame update
    public Rigidbody objectRb;
    private float minSpeed = 12;
    private float maxSpeed = 16;
    private float maxTorque = 10;
    private float xRange = 4;
    private float ySpawnPos = -6;
    private GameManager gameManager;
    public int pointValue;
    public ParticleSystem explosionParticle;
    void Start()
    {
        objectRb = GetComponent<Rigidbody>();
        objectRb.AddForce(RandowForce(), ForceMode.Impulse);
        objectRb.AddTorque(RandowTorque(), RandowTorque(), RandowTorque()
            , ForceMode.Impulse);
        this.transform.position = RandowSpawnPos();
       
      gameManager = GameObject.Find("GameManger").GetComponent<GameManager>();
    
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    Vector3 RandowForce()
    {
        return Vector3.up * Random.Range(minSpeed, maxSpeed);
    }
    float RandowTorque()
    {
        return Random.Range(-maxTorque, maxTorque);
    }
    Vector3 RandowSpawnPos()
    {
        return new Vector3(Random.Range(-xRange, xRange), ySpawnPos);
    }
    private void OnMouseDown()
    {
        if(gameManager.isGameActive)
        {
Destroy(gameObject);
        Instantiate(explosionParticle, transform.position, explosionParticle.transform.rotation);
        gameManager.UpdateScore(pointValue);
        }
        
    }
    private void OnTriggerEnter(Collider other)
    {
        Destroy(gameObject);
        if(!gameObject.CompareTag("Bad"))
        {
            gameManager.GameOver();
        }
    }
}
